
    // const header = document.querySelector(".header");
    // const hero = document.querySelector(".hero");
    // const menu = document.querySelector(".menu")
    // const heroHeight = hero.clientHeight;

    // window.addEventListener("scroll", function() {
    //     const scroll = window.scroll;
    //     console.log('Scroll Position : ', scroll);

    //     if (scroll > heroHeight / 2) {
    //         header.classList.add("sticky-menu");
    //         hero.classList.add("hero-split");

    //     } else {
    //         header.classList.remove("sticky-menu");
    //         hero.classList.remove("hero-split");
    //     }
    // });

    // const hrdiv = document.querySelector('.hrdiv');

    // let position = -100; // Start position
    // const speed = 2;     // Speed of the animation

    // function animateLine() {
    //     position += speed;
    //     hrdiv.style.transform = `translateX(${position}%)`;

    //     // if (position > 100) {
    //     //     position = -50;
    //     //      // Reset position to loop the animation
    //     // }

    //     requestAnimationFrame(animateLine);
        
    // }

    // animateLine();
    